<?php
    $conn=mysqli_connect("localhost","root","","galeri2");
?>